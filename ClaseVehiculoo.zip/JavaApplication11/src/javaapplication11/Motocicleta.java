
package javaapplication11;


public class Motocicleta extends Vehiculo {
    
    private int cilindrada;
    private String tipo_moto;

    public Motocicleta(String tipo_moto, String marca, int cilindrada, double precio, int anio, String modelo) {
        super(marca, modelo, anio, precio);
        this.cilindrada = cilindrada;
        this.tipo_moto = tipo_moto;
    }
    
   public void mostrar_informacion() {
        super.mostrar_informacion();
        System.out.println("Cilindrada: " + cilindrada);
        System.out.println("Tipo de moto: " + tipo_moto);
    }
    
    public Motocicleta() {
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public String getTipo_moto() {
        return tipo_moto;
    }

    public void setTipo_moto(String tipo_moto) {
        this.tipo_moto = tipo_moto;
    }

}