
package javaapplication11;


public class JavaApplication11 {

    
    public static void main(String[] args) {
         
        Vehiculo vehiculo1 = new Vehiculo("BMW", "GR58S", 2018, 65000.0);
        Automovil automovil1 = new Automovil("Ford", "Fina", 2023, 40000.0, "POWER", 4, "Gasolina");
        Motocicleta motocicleta1 = new Motocicleta("Honda", "CBR500R", 2013, 8000.0, 500, "Deportiva");
        
        System.out.println("Informacion del Vehiculo 1:");
        vehiculo1.mostrar_informacion();

        System.out.println("\nInformacion del Automovil 1:");
        automovil1.mostrar_informacion();

        System.out.println("\nInformacion de la Motocicleta 1:");
        motocicleta1.mostrar_informacion();
    
    }
    
}
