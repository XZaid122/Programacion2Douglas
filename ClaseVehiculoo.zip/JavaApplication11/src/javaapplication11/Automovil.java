
package javaapplication11;


public class Automovil extends Vehiculo {
    private String tipo;
    private int puertas;
    private String combustible;

    public Automovil(String tipo, String combustible, int puertas, double precio, String marca, int anio, String modelo) {
        super(marca, modelo, anio, precio);
        this.tipo = tipo;
        this.puertas = puertas;
        this.combustible = combustible;
    }
       public void mostrar_informacion() {
        super.mostrar_informacion();
        System.out.println("Tipo: " + tipo);
        System.out.println("Puertas: " + puertas);
        System.out.println("Combustible: " + combustible);
    }


    public Automovil() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    
}
