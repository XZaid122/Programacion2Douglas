/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.datos;

import java.time.LocalDate;

/**
 *
 * @author Josue
 */
public class Datos {

    public static void main(String[] args) {
        Clientes cliente = new Clientes("1270319", "Douglas", "Araujo", "3043099390", "Douglasjosue31@hotmail.com", "Crespito Cr 14 69A06", LocalDate.of(2002, 7, 31));
        System.out.println(cliente.mensajeCliente());

    }
}
