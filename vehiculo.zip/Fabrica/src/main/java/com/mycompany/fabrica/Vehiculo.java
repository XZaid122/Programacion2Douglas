package com.mycompany.fabrica;

public class Vehiculo {
    
    private String fechaFabricacion;
    private String VINChasis;
    private String VINMotor;

    public Vehiculo(String fechaFabricacion, String VINChasis, String VINMotor) {
        this.fechaFabricacion = fechaFabricacion;
        this.VINChasis = VINChasis;
        this.VINMotor = VINMotor;
    }

    public String getFechaFabricacion() {
        return fechaFabricacion;
    }

    public String getVINChasis() {
        return VINChasis;
    }

    public String getVINMotor() {
        return VINMotor;
    }
    
}
