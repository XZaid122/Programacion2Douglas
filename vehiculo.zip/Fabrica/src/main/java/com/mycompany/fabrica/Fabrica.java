package com.mycompany.fabrica;

public class Fabrica {

    public static void main(String[] args) {
       Automovil automovil = new Automovil("2022-01-01", "ABC123456", "XYZ789012", "Toyota", "Corolla", 25000.0);

       automovil.mostrarDatos();

    }
}
