package com.mycompany.fabrica;

public class Automovil extends Vehiculo {

    
    private String marca;
    private String modelo;
    private double precio;

    public Automovil(String fechaFabricacion, String VINChasis, String VINMotor, String marca, String modelo, double precio) {
        super(fechaFabricacion, VINChasis, VINMotor);
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void mostrarDatos() {
        System.out.println("Datos del automóvil:");
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Precio: $" + precio);
        System.out.println("Fecha de Fabricación: " + getFechaFabricacion());
        System.out.println("VIN del Chasis: " + getVINChasis());
        System.out.println("VIN del Motor: " + getVINMotor());
    }
    }


